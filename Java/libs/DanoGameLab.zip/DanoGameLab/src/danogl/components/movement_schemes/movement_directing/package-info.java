/**
 * The focus of this package is the MovementDirector class. The package
 * also includes its subclasses and helper classes.
 * @author Dan Nirel
 */
package danogl.components.movement_schemes.movement_directing;