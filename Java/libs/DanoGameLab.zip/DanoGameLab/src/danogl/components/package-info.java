/**
 * A few useful components that can be added to a GameObject
 * @author Dan Nirel
 */package danogl.components;